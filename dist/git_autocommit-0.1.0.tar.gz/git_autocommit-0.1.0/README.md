while working my last job i often had trouble making good commit
messages.

the goal is to create a minimal cli tool which takes in the git diff and adds and commits the changes with a solid commit message
